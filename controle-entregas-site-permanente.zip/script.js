// ===== State Management =====
let entregas = [];
let filtroAtual = 'todos';
let editandoId = null;
const STORAGE_KEY = 'controle_entregas_data';
const CONFIG_KEY = 'controle_entregas_config';

// ===== Initialization =====
window.addEventListener('DOMContentLoaded', () => {
    carregarDados();
    definirDataAtual();
    carregarConfigurações();
    atualizarTabela();
    atualizarEstatisticas();
});

// ===== Data Management =====
function carregarDados() {
    const dados = localStorage.getItem(STORAGE_KEY);
    if (dados) {
        try {
            entregas = JSON.parse(dados);
        } catch (e) {
            console.error('Erro ao carregar dados:', e);
            entregas = [];
        }
    }
}

function salvarDados() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(entregas));
        mostrarNotificacao('Dados salvos com sucesso!', 'success');
    } catch (e) {
        console.error('Erro ao salvar dados:', e);
        mostrarNotificacao('Erro ao salvar dados', 'error');
    }
}

// ===== Form Management =====
function definirDataAtual() {
    const hoje = new Date().toISOString().split('T')[0];
    document.getElementById('data').value = hoje;
}

function limparFormulario() {
    document.getElementById('cliente').value = '';
    document.getElementById('endereco').value = '';
    document.getElementById('valor').value = '';
    document.getElementById('observacoes').value = '';
    document.getElementById('status').value = '';
    definirDataAtual();
    editandoId = null;
    document.getElementById('btnSubmit').textContent = 'Adicionar Entrega';
}

function adicionarEntrega(event) {
    event.preventDefault();

    const cliente = document.getElementById('cliente').value.trim();
    const endereco = document.getElementById('endereco').value.trim();
    const data = document.getElementById('data').value;
    const valor = parseFloat(document.getElementById('valor').value);
    const status = document.getElementById('status').value;
    const observacoes = document.getElementById('observacoes').value.trim();

    if (!cliente || !endereco || !data || isNaN(valor) || !status) {
        mostrarNotificacao('Por favor, preencha todos os campos obrigatórios!', 'error');
        return;
    }

    if (valor < 0) {
        mostrarNotificacao('O valor não pode ser negativo!', 'error');
        return;
    }

    if (editandoId !== null) {
        // Editar entrega existente
        const index = entregas.findIndex(e => e.id === editandoId);
        if (index !== -1) {
            entregas[index] = {
                id: editandoId,
                cliente,
                endereco,
                data,
                valor,
                status,
                observacoes,
                dataAtualizacao: new Date().toISOString()
            };
            mostrarNotificacao('Entrega atualizada com sucesso!', 'success');
        }
        editandoId = null;
    } else {
        // Adicionar nova entrega
        const entrega = {
            id: Date.now(),
            cliente,
            endereco,
            data,
            valor,
            status,
            observacoes,
            dataCriacao: new Date().toISOString(),
            dataAtualizacao: new Date().toISOString()
        };
        entregas.push(entrega);
        mostrarNotificacao('Entrega adicionada com sucesso!', 'success');
    }

    salvarDados();
    limparFormulario();
    atualizarTabela();
    atualizarEstatisticas();
    fecharModal();
}

// ===== Edit Management =====
function editarEntrega(id) {
    const entrega = entregas.find(e => e.id === id);
    if (entrega) {
        document.getElementById('editCliente').value = entrega.cliente;
        document.getElementById('editEndereco').value = entrega.endereco;
        document.getElementById('editData').value = entrega.data;
        document.getElementById('editValor').value = entrega.valor;
        document.getElementById('editStatus').value = entrega.status;
        document.getElementById('editObservacoes').value = entrega.observacoes || '';

        editandoId = id;
        document.getElementById('editModal').classList.add('active');
    }
}

function salvarEdicao(event) {
    event.preventDefault();

    const cliente = document.getElementById('editCliente').value.trim();
    const endereco = document.getElementById('editEndereco').value.trim();
    const data = document.getElementById('editData').value;
    const valor = parseFloat(document.getElementById('editValor').value);
    const status = document.getElementById('editStatus').value;
    const observacoes = document.getElementById('editObservacoes').value.trim();

    if (!cliente || !endereco || !data || isNaN(valor) || !status) {
        mostrarNotificacao('Por favor, preencha todos os campos!', 'error');
        return;
    }

    const index = entregas.findIndex(e => e.id === editandoId);
    if (index !== -1) {
        entregas[index] = {
            ...entregas[index],
            cliente,
            endereco,
            data,
            valor,
            status,
            observacoes,
            dataAtualizacao: new Date().toISOString()
        };
        salvarDados();
        atualizarTabela();
        atualizarEstatisticas();
        fecharModal();
        mostrarNotificacao('Entrega atualizada com sucesso!', 'success');
    }
}

function excluirEntrega(id) {
    if (confirm('Tem certeza que deseja excluir esta entrega?')) {
        entregas = entregas.filter(e => e.id !== id);
        salvarDados();
        atualizarTabela();
        atualizarEstatisticas();
        mostrarNotificacao('Entrega excluída com sucesso!', 'success');
    }
}

// ===== Table Management =====
function atualizarTabela() {
    const tbody = document.getElementById('tabelaEntregas');
    tbody.innerHTML = '';

    let entregasFiltradas = entregas;

    if (filtroAtual !== 'todos') {
        entregasFiltradas = entregas.filter(e => e.status === filtroAtual);
    }

    // Aplicar busca se houver
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    if (searchTerm) {
        entregasFiltradas = entregasFiltradas.filter(e =>
            e.cliente.toLowerCase().includes(searchTerm) ||
            e.endereco.toLowerCase().includes(searchTerm) ||
            e.data.includes(searchTerm)
        );
    }

    // Ordenar por data (mais recente primeiro)
    entregasFiltradas.sort((a, b) => new Date(b.data) - new Date(a.data));

    // Atualizar contagem de busca
    const searchCount = document.getElementById('searchCount');
    if (searchCount && searchTerm) {
        searchCount.textContent = `${entregasFiltradas.length} resultado(s)`;
    }

    if (entregasFiltradas.length === 0) {
        tbody.innerHTML = '<tr class="empty-state"><td colspan="7">Nenhuma entrega encontrada.</td></tr>';
        return;
    }

    entregasFiltradas.forEach(entrega => {
        const tr = document.createElement('tr');

        const statusClass = `status-${entrega.status
            .toLowerCase()
            .replace(/\s+/g, '-')
            .replace('ã', 'a')
            .replace('á', 'a')
            .replace('é', 'e')}`;

        tr.innerHTML = `
            <td><strong>${entrega.cliente}</strong></td>
            <td>${entrega.endereco}</td>
            <td>${formatarData(entrega.data)}</td>
            <td><strong>R$ ${entrega.valor.toFixed(2).replace('.', ',')}</strong></td>
            <td><span class="${statusClass}">${entrega.status}</span></td>
            <td>${entrega.observacoes ? `<small>${entrega.observacoes.substring(0, 30)}...</small>` : '<small style="color: #999;">-</small>'}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn-action btn-edit" onclick="editarEntrega(${entrega.id})">✏️ Editar</button>
                    <button class="btn-action btn-delete" onclick="excluirEntrega(${entrega.id})">🗑️ Excluir</button>
                </div>
            </td>
        `;

        tbody.appendChild(tr);
    });
}

// ===== Filter Management =====
function filtrarEntregas(filtro) {
    filtroAtual = filtro;

    // Atualizar botões ativos
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.closest('.filter-btn').classList.add('active');

    atualizarTabela();
}

function pesquisarEntregas() {
    atualizarTabela();
}

// ===== Statistics =====
function atualizarEstatisticas() {
    const hoje = new Date().toISOString().split('T')[0];

    // Total do dia
    const totalDia = entregas
        .filter(e => e.data === hoje)
        .reduce((sum, e) => sum + e.valor, 0);

    // Não pagos
    const naoPagos = entregas
        .filter(e => e.status === 'Não pago')
        .reduce((sum, e) => sum + e.valor, 0);

    // Total geral
    const totalGeral = entregas.reduce((sum, e) => sum + e.valor, 0);

    // Total de entregas
    const totalEntregas = entregas.length;

    document.getElementById('totalDia').textContent = `R$ ${totalDia.toFixed(2).replace('.', ',')}`;
    document.getElementById('naoPagos').textContent = `R$ ${naoPagos.toFixed(2).replace('.', ',')}`;
    document.getElementById('totalGeral').textContent = `R$ ${totalGeral.toFixed(2).replace('.', ',')}`;
    document.getElementById('totalEntregas').textContent = totalEntregas;
}

// ===== Export Functions =====
function exportarExcel() {
    if (entregas.length === 0) {
        mostrarNotificacao('Não há entregas para exportar!', 'error');
        return;
    }

    let entregasFiltradas = entregas;

    if (filtroAtual !== 'todos') {
        entregasFiltradas = entregas.filter(e => e.status === filtroAtual);
    }

    if (entregasFiltradas.length === 0) {
        mostrarNotificacao('Não há entregas no filtro atual para exportar!', 'error');
        return;
    }

    // Criar CSV
    let csv = '\uFEFF'; // BOM para UTF-8
    csv += 'Cliente;Endereço;Data;Valor;Status;Observações\n';

    entregasFiltradas.forEach(entrega => {
        csv += `"${entrega.cliente}";"${entrega.endereco}";"${formatarData(entrega.data)}";"R$ ${entrega.valor.toFixed(2).replace('.', ',')}";"${entrega.status}";"${(entrega.observacoes || '').replace(/"/g, '""')}"\n`;
    });

    // Criar blob e download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    link.setAttribute('href', url);
    link.setAttribute('download', `entregas_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    mostrarNotificacao('Arquivo exportado com sucesso!', 'success');
}

function imprimirRelatorio() {
    window.print();
    mostrarNotificacao('Abrindo visualização de impressão...', 'info');
}

// ===== Backup Functions =====
function fazerBackup() {
    if (entregas.length === 0) {
        mostrarNotificacao('Não há dados para fazer backup!', 'error');
        return;
    }

    const backup = {
        data: entregas,
        dataCriacao: new Date().toISOString(),
        versao: '2.0'
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    link.setAttribute('href', url);
    link.setAttribute('download', `backup_entregas_${new Date().toISOString().split('T')[0]}.json`);
    link.style.visibility = 'hidden';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    mostrarNotificacao('Backup criado com sucesso!', 'success');
}

function restaurarBackup(arquivo) {
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const backup = JSON.parse(e.target.result);
            if (backup.data && Array.isArray(backup.data)) {
                if (confirm('Tem certeza que deseja restaurar este backup? Os dados atuais serão substituídos.')) {
                    entregas = backup.data;
                    salvarDados();
                    atualizarTabela();
                    atualizarEstatisticas();
                    mostrarNotificacao('Backup restaurado com sucesso!', 'success');
                }
            } else {
                mostrarNotificacao('Arquivo de backup inválido!', 'error');
            }
        } catch (erro) {
            mostrarNotificacao('Erro ao ler o arquivo de backup!', 'error');
        }
    };
    reader.readAsText(arquivo);
}

// ===== Data Management =====
function limparDados() {
    if (confirm('Tem certeza que deseja limpar TODOS os dados? Esta ação não pode ser desfeita!')) {
        if (confirm('Confirme novamente: deseja realmente excluir todos os dados?')) {
            entregas = [];
            salvarDados();
            atualizarTabela();
            atualizarEstatisticas();
            mostrarNotificacao('Todos os dados foram excluídos!', 'success');
        }
    }
}

// ===== Modal Management =====
function fecharModal() {
    document.getElementById('editModal').classList.remove('active');
    editandoId = null;
}

function abrirConfigurações() {
    document.getElementById('configModal').classList.add('active');
}

function fecharConfigModal() {
    document.getElementById('configModal').classList.remove('active');
}

// Fechar modal ao clicar fora
document.addEventListener('click', (e) => {
    const editModal = document.getElementById('editModal');
    const configModal = document.getElementById('configModal');

    if (e.target === editModal) {
        fecharModal();
    }
    if (e.target === configModal) {
        fecharConfigModal();
    }
});

// ===== Theme Management =====
function carregarConfigurações() {
    const config = localStorage.getItem(CONFIG_KEY);
    if (config) {
        try {
            const cfg = JSON.parse(config);
            if (cfg.darkMode) {
                document.body.classList.add('dark-mode');
                document.getElementById('darkMode').checked = true;
            }
            if (cfg.notificacoes !== undefined) {
                document.getElementById('notificacoes').checked = cfg.notificacoes;
            }
        } catch (e) {
            console.error('Erro ao carregar configurações:', e);
        }
    }
}

function salvarConfigurações() {
    const config = {
        darkMode: document.body.classList.contains('dark-mode'),
        notificacoes: document.getElementById('notificacoes').checked
    };
    localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
}

function alternarModoEscuro() {
    document.body.classList.toggle('dark-mode');
    salvarConfigurações();
}

// ===== Notifications =====
function mostrarNotificacao(mensagem, tipo = 'info') {
    if (!document.getElementById('notificacoes')?.checked) {
        return;
    }

    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 16px 20px;
        background: ${tipo === 'success' ? '#10b981' : tipo === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 2000;
        animation: slideIn 0.3s ease;
        font-weight: 500;
    `;
    notif.textContent = mensagem;

    document.body.appendChild(notif);

    setTimeout(() => {
        notif.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

// ===== Utility Functions =====
function formatarData(data) {
    const [ano, mes, dia] = data.split('-');
    return `${dia}/${mes}/${ano}`;
}

// ===== Keyboard Shortcuts =====
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
        if (e.key === 's') {
            e.preventDefault();
            salvarDados();
        }
        if (e.key === 'e') {
            e.preventDefault();
            exportarExcel();
        }
    }
    if (e.key === 'Escape') {
        fecharModal();
        fecharConfigModal();
    }
});

// ===== CSS Animation Injection =====
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ===== Performance Optimization =====
// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

const pesquisarDebounced = debounce(() => {
    pesquisarEntregas();
}, 300);

document.getElementById('searchInput')?.addEventListener('keyup', pesquisarDebounced);
