# 🌐 Guia Completo de Hospedagem - Controle de Entregas

Este guia apresenta passo a passo como hospedar o Controle de Entregas em diferentes plataformas.

## 📋 Índice

1. [GitHub Pages (Recomendado)](#github-pages)
2. [Netlify](#netlify)
3. [Vercel](#vercel)
4. [Servidor Web Local](#servidor-web-local)
5. [Hospedagem Compartilhada](#hospedagem-compartilhada)
6. [Domínio Personalizado](#domínio-personalizado)

---

## 🐙 GitHub Pages (Recomendado)

GitHub Pages é **gratuito**, **fácil** e **perfeito** para este projeto.

### Passo 1: Criar Conta no GitHub
1. Acesse [github.com](https://github.com)
2. Clique em "Sign up"
3. Preencha seus dados e confirme o email

### Passo 2: Criar Repositório
1. Clique no ícone `+` no canto superior direito
2. Selecione "New repository"
3. Preencha os dados:
   - **Repository name**: `controle-entregas` (ou outro nome)
   - **Description**: "Sistema de controle de entregas"
   - **Public**: Sim (necessário para GitHub Pages)
   - **Add a README file**: Não (vamos usar o nosso)

### Passo 3: Upload dos Arquivos
1. Clique em "Add file" → "Upload files"
2. Selecione todos os arquivos do projeto:
   - `index.html`
   - `styles.css`
   - `script.js`
   - `README.md`
   - `.htaccess` (opcional)
3. Clique em "Commit changes"

### Passo 4: Ativar GitHub Pages
1. Vá para "Settings" do repositório
2. No menu lateral, clique em "Pages"
3. Em "Source", selecione "Deploy from a branch"
4. Selecione "main" como branch
5. Clique em "Save"
6. Aguarde alguns minutos (GitHub vai processar)

### Passo 5: Acessar seu Site
Seu site estará disponível em:
```
https://seu-usuario.github.io/controle-entregas
```

**Exemplo**: `https://joaosilva.github.io/controle-entregas`

---

## 🔗 Netlify

Netlify oferece hospedagem gratuita com deploy automático.

### Passo 1: Criar Conta
1. Acesse [netlify.com](https://netlify.com)
2. Clique em "Sign up"
3. Escolha "GitHub" para facilitar

### Passo 2: Conectar Repositório
1. Clique em "New site from Git"
2. Selecione "GitHub"
3. Autorize o Netlify a acessar seus repositórios
4. Selecione o repositório `controle-entregas`

### Passo 3: Configurar Build
1. **Build command**: Deixe em branco (não há build)
2. **Publish directory**: `.` (raiz do projeto)
3. Clique em "Deploy site"

### Passo 4: Acessar seu Site
Seu site estará disponível em uma URL como:
```
https://seu-site-aleatorio.netlify.app
```

### Passo 5: Personalizar URL (Opcional)
1. Vá para "Site settings"
2. Clique em "Change site name"
3. Digite um novo nome (ex: `controle-entregas`)
4. Seu site estará em: `https://controle-entregas.netlify.app`

---

## ⚡ Vercel

Vercel é extremamente rápido e fácil de usar.

### Passo 1: Criar Conta
1. Acesse [vercel.com](https://vercel.com)
2. Clique em "Sign Up"
3. Escolha "Continue with GitHub"

### Passo 2: Importar Projeto
1. Clique em "New Project"
2. Selecione "Import Git Repository"
3. Selecione seu repositório `controle-entregas`

### Passo 3: Deploy
1. Clique em "Deploy"
2. Aguarde o deploy completar (geralmente 30 segundos)

### Passo 4: Acessar seu Site
Seu site estará em:
```
https://controle-entregas.vercel.app
```

---

## 💻 Servidor Web Local

Para testar localmente antes de hospedar.

### Usando Python 3
```bash
# Navegue até a pasta do projeto
cd /caminho/para/controle-entregas

# Inicie o servidor
python -m http.server 8000

# Abra no navegador
# http://localhost:8000
```

### Usando Node.js
```bash
# Instale http-server (primeira vez)
npm install -g http-server

# Inicie o servidor
http-server

# Abra no navegador
# http://localhost:8080
```

### Usando PHP
```bash
# Navegue até a pasta
cd /caminho/para/controle-entregas

# Inicie o servidor
php -S localhost:8000

# Abra no navegador
# http://localhost:8000
```

---

## 🏢 Hospedagem Compartilhada

Para hospedagem em servidores compartilhados (Hostinger, Bluehost, etc).

### Passo 1: Fazer Upload dos Arquivos
1. Acesse o painel de controle (cPanel, Plesk, etc)
2. Abra o gerenciador de arquivos
3. Navegue até a pasta `public_html`
4. Faça upload de todos os arquivos:
   - `index.html`
   - `styles.css`
   - `script.js`
   - `README.md`
   - `.htaccess` (se disponível)

### Passo 2: Configurar Domínio (Opcional)
1. Vá para "Domínios" ou "Addon Domains"
2. Aponte seu domínio para a pasta onde você fez upload
3. Aguarde a propagação do DNS (até 24 horas)

### Passo 3: Acessar seu Site
```
https://seu-dominio.com
```

---

## 🎯 Domínio Personalizado

Todos os serviços acima permitem usar um domínio personalizado.

### Opções de Domínio
- **Namecheap** (barato)
- **GoDaddy** (popular)
- **Google Domains** (confiável)
- **Registro.br** (domínios .br)

### Configurar Domínio no GitHub Pages
1. Compre um domínio
2. Vá para as configurações de DNS do domínio
3. Adicione um registro `CNAME`:
   - **Name**: `www`
   - **Value**: `seu-usuario.github.io`
4. Adicione um registro `A` (opcional):
   - **IP**: `185.199.108.153`
   - **IP**: `185.199.109.153`
   - **IP**: `185.199.110.153`
   - **IP**: `185.199.111.153`
5. No repositório, vá para Settings → Pages
6. Em "Custom domain", digite seu domínio
7. Clique em "Save"

### Configurar Domínio no Netlify
1. Compre um domínio
2. No Netlify, vá para "Site settings" → "Domain management"
3. Clique em "Add custom domain"
4. Digite seu domínio
5. Siga as instruções para configurar o DNS

### Configurar Domínio no Vercel
1. Compre um domínio
2. No Vercel, vá para "Settings" → "Domains"
3. Clique em "Add"
4. Digite seu domínio
5. Configure o DNS conforme instruções

---

## 📊 Comparação de Plataformas

| Plataforma | Custo | Facilidade | Performance | Recomendado |
|-----------|-------|-----------|-------------|------------|
| GitHub Pages | Grátis | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ✅ |
| Netlify | Grátis | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ |
| Vercel | Grátis | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ |
| Hospedagem Compartilhada | $3-10/mês | ⭐⭐⭐ | ⭐⭐⭐ | - |

---

## 🔒 Segurança

### Boas Práticas
- ✅ Todos os dados são armazenados **localmente**
- ✅ Nenhuma informação é enviada para servidores
- ✅ Use HTTPS (todos os serviços acima oferecem)
- ✅ Faça backup regularmente
- ✅ Não compartilhe arquivos de backup

### Certificado SSL
- GitHub Pages: Automático
- Netlify: Automático
- Vercel: Automático
- Hospedagem Compartilhada: Geralmente incluído

---

## 🚀 Próximos Passos

Após hospedar seu site:

1. **Teste todas as funcionalidades**
   - Adicione entregas
   - Teste filtros
   - Exporte dados
   - Teste em mobile

2. **Configure um domínio personalizado** (opcional)
   - Torna seu site mais profissional
   - Facilita compartilhamento

3. **Faça backup regularmente**
   - Use a função de backup do sistema
   - Guarde em local seguro

4. **Compartilhe com sua equipe**
   - Envie o link do site
   - Todos podem usar simultaneamente
   - Cada um tem seus dados locais

---

## ❓ Dúvidas Frequentes

### P: Preciso de um servidor backend?
**R**: Não! Este é um aplicativo 100% frontend. Funciona completamente no navegador.

### P: Meus dados são seguros?
**R**: Sim! Todos os dados ficam no seu navegador. Ninguém tem acesso a eles.

### P: Posso usar em mobile?
**R**: Sim! O site é totalmente responsivo e funciona em qualquer dispositivo.

### P: Quanto custa?
**R**: Totalmente grátis! GitHub Pages, Netlify e Vercel oferecem hospedagem gratuita.

### P: E se eu quiser um domínio personalizado?
**R**: Domínios custam cerca de R$ 30-50 por ano. Você pode comprar em qualquer registrador.

### P: Posso usar offline?
**R**: Sim! Após carregar uma vez, o site funciona offline (com limitações).

### P: Como faço backup dos dados?
**R**: Clique no botão 💾 no cabeçalho. Um arquivo JSON será baixado.

### P: Posso compartilhar o link com outras pessoas?
**R**: Sim! Mas cada pessoa terá seus próprios dados (armazenados localmente).

---

## 📞 Suporte

Se tiver dúvidas:
1. Consulte a documentação (README.md)
2. Teste em outro navegador
3. Limpe o cache e tente novamente
4. Verifique se JavaScript está ativado

---

**Pronto para hospedar? Escolha uma plataforma acima e comece agora!** 🚀
