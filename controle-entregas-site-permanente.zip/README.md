# 📦 Controle de Entregas - Sistema Profissional v2.0

Um sistema web moderno e responsivo para gerenciar entregas, rastrear status de pedidos e gerar relatórios. Totalmente funcional sem necessidade de servidor backend.

## ✨ Características Principais

### Gerenciamento Completo de Entregas
- **Cadastro**: Adicione entregas com cliente, endereço, data, valor e status
- **Edição**: Modifique entregas existentes a qualquer momento
- **Exclusão**: Remova entregas com confirmação de segurança
- **Observações**: Adicione notas adicionais a cada entrega

### Sistema de Status Flexível
- 🗓️ **Agendado** - Entrega agendada
- 🚚 **Em andamento** - Entrega em processo
- ✅ **Entregue** - Entrega realizada
- ✔️ **Pago** - Pagamento recebido
- ❌ **Não pago** - Aguardando pagamento

### Filtros e Busca Avançada
- Filtrar entregas por status com um clique
- Busca em tempo real por cliente, endereço ou data
- Visualização de todas as entregas ou filtradas

### Estatísticas em Tempo Real
- **Total do Dia**: Soma de todas as entregas da data atual
- **Não Pagos**: Total de valores pendentes
- **Total Geral**: Soma de todas as entregas cadastradas
- **Contagem**: Número total de entregas

### Exportação e Relatórios
- **Exportar para Excel**: Gera arquivo CSV compatível com Excel
- **Imprimir**: Visualização otimizada para impressão
- **Backup**: Crie backups dos seus dados
- **Restaurar**: Restaure dados de um backup anterior

### Interface Profissional
- Design moderno e intuitivo
- **Modo Escuro**: Alterne entre temas claro e escuro
- **Responsivo**: Funciona perfeitamente em desktop, tablet e mobile
- **Notificações**: Feedback visual de todas as ações

### Armazenamento Local
- Todos os dados salvos no navegador (localStorage)
- Sem necessidade de servidor ou banco de dados
- Funciona offline
- Dados persistem entre sessões

## 🚀 Como Usar

### Instalação
1. Baixe os arquivos do projeto
2. Coloque em um servidor web ou abra o `index.html` diretamente no navegador
3. Pronto! O sistema está funcionando

### Primeiro Uso
1. Preencha o formulário com os dados da entrega
2. Clique em "Adicionar Entrega"
3. A entrega aparecerá na tabela abaixo
4. Use os filtros para organizar suas entregas

### Gerenciar Entregas
- **Editar**: Clique no botão "Editar" na linha da entrega
- **Excluir**: Clique em "Excluir" e confirme
- **Filtrar**: Use os botões de filtro para visualizar por status
- **Buscar**: Use a barra de busca para encontrar entregas específicas

### Exportar Dados
- **Excel**: Clique em "Exportar para Excel" para baixar um arquivo CSV
- **Imprimir**: Clique em "Imprimir" para visualizar e imprimir
- **Backup**: Use o botão de backup para salvar seus dados

### Configurações
- Clique no ícone ⚙️ no cabeçalho para acessar configurações
- Ative/desative modo escuro
- Ative/desative notificações

## 📋 Atalhos de Teclado

| Atalho | Ação |
|--------|------|
| `Ctrl + S` | Salvar dados |
| `Ctrl + E` | Exportar para Excel |
| `Esc` | Fechar modal |

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica e acessibilidade
- **CSS3**: Design responsivo com variáveis CSS
- **JavaScript (ES6+)**: Lógica moderna e otimizada
- **LocalStorage**: Persistência de dados no navegador

## 📱 Compatibilidade

### Navegadores Suportados
- ✅ Google Chrome (recomendado)
- ✅ Mozilla Firefox
- ✅ Microsoft Edge
- ✅ Safari
- ✅ Opera
- ✅ Navegadores mobile (Chrome, Safari, Firefox)

### Requisitos
- Navegador moderno com suporte a ES6
- JavaScript ativado
- LocalStorage disponível

## 🌐 Hospedagem

### Opções de Hospedagem Gratuita

#### 1. **GitHub Pages** (Recomendado)
```bash
1. Crie um repositório no GitHub
2. Faça upload dos arquivos
3. Ative GitHub Pages nas configurações
4. Seu site estará em: https://seu-usuario.github.io/seu-repositorio
```

#### 2. **Netlify**
```bash
1. Acesse netlify.com
2. Conecte seu repositório GitHub
3. Configure o build (não necessário para este projeto)
4. Deploy automático
```

#### 3. **Vercel**
```bash
1. Acesse vercel.com
2. Importe seu projeto
3. Deploy instantâneo
```

#### 4. **Servidor Web Local**
```bash
# Python 3
python -m http.server 8000

# Node.js (com http-server)
npx http-server

# PHP
php -S localhost:8000
```

### Hospedagem Paga

Qualquer servidor web que suporte arquivos estáticos (HTML, CSS, JS):
- Hostinger
- Bluehost
- SiteGround
- AWS S3
- Google Cloud Storage
- Azure Static Web Apps

## 💾 Backup e Restauração

### Fazer Backup
1. Clique no ícone 💾 no cabeçalho
2. Um arquivo JSON será baixado automaticamente
3. Guarde este arquivo em local seguro

### Restaurar Backup
1. Clique no ícone 💾 novamente
2. Selecione o arquivo de backup
3. Confirme a restauração

### Exportar para Excel
1. Clique em "Exportar para Excel"
2. Um arquivo CSV será baixado
3. Abra em Excel, Google Sheets ou LibreOffice

## 🔒 Privacidade e Segurança

- ✅ Todos os dados são armazenados **localmente** no seu navegador
- ✅ Nenhuma informação é enviada para servidores externos
- ✅ Seus dados estão sob seu controle total
- ✅ Limpe o cache do navegador para deletar os dados

### Proteção de Dados
- Use a função de backup regularmente
- Guarde seus backups em local seguro
- Não compartilhe o arquivo de backup com terceiros

## 🐛 Solução de Problemas

### Os dados desapareceram
- **Causa**: Cache do navegador foi limpo
- **Solução**: Restaure a partir de um backup anterior

### O sistema está lento
- **Causa**: Muitos registros (1000+)
- **Solução**: Exporte dados antigos e limpe o histórico

### Não consigo adicionar entregas
- **Verificar**: Todos os campos obrigatórios estão preenchidos?
- **Verificar**: O valor é um número válido?
- **Verificar**: JavaScript está ativado no navegador?

### Modo escuro não funciona
- **Solução**: Recarregue a página
- **Solução**: Limpe o cache do navegador

## 📊 Casos de Uso

- 🚚 Empresas de delivery e logística
- 📦 Transportadoras
- 🏪 E-commerce e lojas online
- 🛵 Serviços de entrega local
- 📋 Controle pessoal de encomendas
- 💼 Pequenas e médias empresas

## 🎯 Roadmap Futuro

- [ ] Integração com APIs de pagamento
- [ ] Gráficos e dashboards avançados
- [ ] Sistema de usuários e autenticação
- [ ] Sincronização em nuvem
- [ ] Aplicativo mobile nativo
- [ ] Integração com WhatsApp
- [ ] Rastreamento GPS
- [ ] Notificações por email/SMS

## 📞 Suporte

Para dúvidas ou sugestões:
1. Verifique a documentação acima
2. Teste em outro navegador
3. Limpe o cache e tente novamente

## 📄 Licença

Este projeto é de código aberto e pode ser usado livremente para fins pessoais e comerciais.

## 🙏 Agradecimentos

Desenvolvido com ❤️ para facilitar o controle de entregas.

---

**Versão**: 2.0  
**Última Atualização**: Janeiro de 2026  
**Status**: ✅ Produção
